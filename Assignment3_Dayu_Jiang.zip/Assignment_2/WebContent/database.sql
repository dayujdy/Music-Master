DROP DATABASE if exists calendar;

CREATE DATABASE calendar;

USE calendar;

CREATE TABLE Users_ (
  gmail varchar(200) primary key not null,
  fname varchar(200) not null,
  lname varchar(200) not null,
  propic varchar(200) not null
  
);

CREATE TABLE Event_ (
  eventID int(11) primary key not null auto_increment,
  gmail_ varchar(200) not null,
  date_ varchar(200) not null,
  time_ varchar(200) not null,
  summary_ varchar(200) not null,
  FOREIGN KEY (gmail_) REFERENCES Users_ (gmail)
);

CREATE TABLE followRelations (
  relationID int(11) primary key not null auto_increment,
  UGmail varchar(200) not null,
  FGmail varchar(200) not null,
  FOREIGN KEY (UGmail) REFERENCES Users_ (gmail),
  FOREIGN KEY (FGmail) REFERENCES Users_ (gmail)
);