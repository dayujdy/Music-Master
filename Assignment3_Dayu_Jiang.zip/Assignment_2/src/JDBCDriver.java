
import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import java.util.ArrayList;

public class JDBCDriver {

	private static Connection conn = null;
	private static ResultSet rs = null;
	private static PreparedStatement ps = null;
	private static user currUser=new user();
	
	public static void test() {
		
	}
	public static void main(String [] args) {
		connect();
	}
	public static void connect(){
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/calendar?user=root&password=Jiang13902956642&useSSL=false&serverTimezone=UTC");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void close(){
		try{
			if (rs!=null){
				rs.close();
				rs = null;
			}
			if(conn != null){
				conn.close();
				conn = null;
			}
			if(ps != null ){
				ps = null;
			}
		}catch(SQLException sqle){
			
			sqle.printStackTrace();
		}
	}
	
	public static void setUser(String userfname,String userlname, String userEmail, String img_link) {
		
		currUser.userfname = userfname;
		currUser.userlname = userlname;
		currUser.userEmail = userEmail;
		currUser.image_link = img_link;
		
		connect();
		try {
			
			ps = conn.prepareStatement("SELECT gmail FROM Users_ WHERE gmail = '"+currUser.userEmail+"'");
			
			rs = ps.executeQuery();
			
			if(!rs.next()){
				System.out.println("inserting to users");
				ps = conn.prepareStatement("INSERT INTO Users_ (gmail, fname, lname, propic) value (?,?,?,?);");
				ps.setString(1, currUser.userEmail);
				ps.setString(2, currUser.userfname);
				ps.setString(3, currUser.userlname);
				ps.setString(4, currUser.image_link);
				ps.executeUpdate();
			}else {
				//System.out.println(rs.getString("userEmail"));
			}
			rs.close();
		}catch(SQLException sqle){
			System.out.println("SQLException in function \"setUser\"");
			sqle.printStackTrace();
		}
	}
	
	public static void updateEvent(String date_, String time_, String summary_){
		connect();
		try {
			ps = conn.prepareStatement("SELECT gmail_, date_, time_,  summary_ FROM Event_ WHERE gmail_ = '"+currUser.userEmail+"'");
			
			rs = ps.executeQuery();
			List<String> eventInfoAll = new ArrayList<>();
			while(rs.next()){
				eventInfoAll.add(rs.getString("gmail_")+ rs.getString("date_")+rs.getString("time_") + rs.getString("summary_"));
			}
			
			boolean exist = false;
			for(String info: eventInfoAll) {
				if(info.equals(currUser.userEmail+date_+time_+summary_)) {
					exist = true;
				}
			}
			if(!exist) {
				ps = conn.prepareStatement("INSERT INTO Event_ ( gmail_, date_, time_,  summary_) value (?,?,?,?);",  Statement.RETURN_GENERATED_KEYS);
				
				ps.setString(1, currUser.userEmail);
				ps.setString(2, date_);
				ps.setString(3, time_);
				ps.setString(4, summary_);
				ps.executeUpdate();
			}
			rs.close();
		}catch(SQLException sqle){
			System.out.println("SQLException in function \"setUser\"");
			sqle.printStackTrace();
		}
	}
	
	public static ArrayList<user> searchUser(String input){
		ArrayList<user> result = new ArrayList<>();
		String[] arr = input.split(" ");
		
		try {
			ps = conn.prepareStatement("SELECT gmail, fname, lname, propic FROM Users_");
			rs = ps.executeQuery();
			System.out.println("here");
			while(rs.next()){
				System.out.println("here");
				if((rs.getString("fname")).contains(currUser.userfname) &&
						(rs.getString("lname")).contains(currUser.userlname))continue;
				boolean contains = false;
				for(int i=0;i<arr.length; i++) {
					if(rs.getString("fname").toLowerCase().contains(arr[i].toLowerCase()) || rs.getString("lname").toLowerCase().contains(arr[i].toLowerCase())) {
						contains=true;
					}
				}
				if(contains) {
					user adding = new user();
					adding.userEmail = rs.getString("gmail");
					adding.userfname =rs.getString("fname");
					adding.userlname = rs.getString("lname");
					adding.image_link = rs.getString("propic");
					result.add(adding);
					System.out.println(adding.userEmail+" "+ adding.userfname+" "
								+ adding.userlname+" "+ adding.image_link);
				}
			}
			
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(int i=0;i<result.size();i++) {
			System.out.println(result.get(i).userEmail);
		}
		return result;
	}

	public static ArrayList<String> getInfo(String email) {
		ArrayList<String> result=new ArrayList<>();
		try {
			ps = conn.prepareStatement("SELECT FGmail FROM followRelations WHERE UGmail = '"+currUser.userEmail+"'");
			rs = ps.executeQuery();
			String following="0";
			while(rs.next()) {
				if(rs.getString("FGmail").equals(email)) {
					following = "1";
				}
			}
			result.add(following);
			ps = conn.prepareStatement("SELECT fname, lname, propic FROM Users_ WHERE gmail = '"+email+"'");
			rs = ps.executeQuery();
			if(rs.next()) {
				result.add(rs.getString("fname"));
				result.add(rs.getString("lname"));
				result.add(rs.getString("propic"));
				//get events info
				ps = conn.prepareStatement("SELECT date_, time_, summary_ FROM events WHERE gmail_ = '"+email+"'");
				rs = ps.executeQuery();
				while(rs.next()) {
					System.out.println(rs.getString("summary_"));
					result.add(rs.getString("summary_"));
					result.add(rs.getString("date_"));
					result.add(rs.getString("time_"));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	public static void setFollow(String email) {
		try {
			ps = conn.prepareStatement("INSERT INTO following ( UGmail, FGmail) value (?,?);");
			ps.setString(1, currUser.userEmail);
			ps.setString(2, email);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static ArrayList<user> userFollowing() {
		ArrayList<user> result = new ArrayList<>();
		try {
			ps = conn.prepareStatement("SELECT FGmail FROM followRelations WHERE UGmail = '"+currUser.userEmail+"'");
			rs = ps.executeQuery();
			ArrayList<String> resultEmails = new ArrayList<>();
			while(rs.next()) {
				resultEmails.add(rs.getString("FGmail"));
			}
			for(String email:resultEmails){
				ps = conn.prepareStatement("SELECT gmail, fname, lname, propic FROM Users_ where gmail = '"
											+email+"'");
				rs = ps.executeQuery();
				if(rs.next())
				{
					user adding = new user();
					adding.userEmail = rs.getString("gmail");
					adding.userfname =rs.getString("fname");
					adding.userlname = rs.getString("lname");
					adding.image_link = rs.getString("propic");
					result.add(adding);
				}
			}
			
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
  }