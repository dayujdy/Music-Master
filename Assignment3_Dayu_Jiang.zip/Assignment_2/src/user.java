
public class user {
	public String userEmail;
	public String userfname;
	public String userlname;
	public String image_link;
}
