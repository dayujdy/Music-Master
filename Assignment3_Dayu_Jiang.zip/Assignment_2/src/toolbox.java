

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/toolbox")
public class toolbox extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String field= request.getParameter("field");
		//PrintWriter out = response.getWriter();
		
		if(field.equals("userInfo")) {
			
			String userfname= request.getParameter("fname");
			String userlname= request.getParameter("lname");
			String gmail= request.getParameter("gmail");
			String propic= request.getParameter("propic");
			
			JDBCDriver.setUser(userfname, userlname, gmail, propic);
		}
		if(field.equals("eventInfo")) {
			
			String summary_= request.getParameter("summary_");
			String date_= request.getParameter("date_");
			String time_= request.getParameter("time_");
			JDBCDriver.updateEvent(date_,time_, summary_);
		}
		if(field.equals("search")) {
			PrintWriter out = response.getWriter();
			
			String input= request.getParameter("input");
			ArrayList<user> resultUsers = JDBCDriver.searchUser(input);
			for(user u: resultUsers) {
				out.println("<div class=\"searchpic\" onClick=\"cookieEmail('"+u.userEmail+"')\">\r\n" + 
								"<img src=\""+ u.image_link +"\" alt=\"picture\">\r\n" + 
								"<a href=\"Usercalendar.jsp?e="+ u.userfname+" "+ u.userlname+" "+u.image_link+ "\"> <h3>"+u.userfname + " " + u.userlname+"</h3></a>\r\n" + "</div>");
				
			}
			if(resultUsers.size()==0) {
				out.println("<h1>User doesn't exist.</h1>");
			}
		}
		if(field.equals("following")) {
			PrintWriter out = response.getWriter();
			String email= request.getParameter("email");
			ArrayList<String> allInfo = JDBCDriver.getInfo(email);
			
			for(String info: allInfo) {
				out.println(info);
				System.out.println(info);
			}
		}
		if(field.equals("followHer")) {
			String email= request.getParameter("email");
			JDBCDriver.setFollow(email);
			
		}
		if(field.equals("homeFollow")) {
			PrintWriter out = response.getWriter();
			ArrayList<user> resultUsers = JDBCDriver.userFollowing();
			out.println("<h2>Following</h2>");
			for(user u: resultUsers) {
				System.out.println(u.userfname + u.userlname);
				out.println("<div class=\"one_fourth\" onClick=\"cookieEmail('"+u.userEmail+"')\">\r\n" + 
								"<img src=\""+ u.image_link +"\" alt=\"main-leaf\">\r\n" + 
								"<h3>"+u.userfname + u.userlname+"</h3>\r\n" + 
							"</div>");
			}
		}
	}
}

